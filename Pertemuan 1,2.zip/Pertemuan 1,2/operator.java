public class operator {
    public static void main(String[] args) {
        //OPERATOR
        // +, -, *, /, %, ++, --, +=, -=

        int a = 2;
        int b = 2;
        int hasil = a % b;
        System.out.println(hasil);
        a++;
        System.out.println(a);

    }
}
 