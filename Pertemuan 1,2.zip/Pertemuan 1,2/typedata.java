public class typedata {
    public static void main(String[] args) {
       String nama [] = new String [2];
       nama[0]= "yudi";
       nama[1]="asep";
       System.out.println("Nama : " + nama[2]);
    }
}
